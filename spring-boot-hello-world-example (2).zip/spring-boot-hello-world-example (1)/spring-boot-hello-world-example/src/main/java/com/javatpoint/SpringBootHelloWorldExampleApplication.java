package com.javatpoint;


import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.web.bind.annotation.*;

@RestController
@EnableAutoConfiguration
public class SpringBootHelloWorldExampleApplication
{ 
	 @RequestMapping("/home")
	    String home() {
	        return "index.html";
	    }
	 
	
public static void main(String[] args) 
{
SpringApplication.run(SpringBootHelloWorldExampleApplication.class, args);
}
}